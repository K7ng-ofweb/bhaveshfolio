const Invoice = require("../models/Invoice");
const generateInvoicePDF = require("../utils/generateInvoicePDF");

exports.createInvoice = async (req, res) => {
  const invoice = await Invoice.create({
    ...req.body,
    invoiceNumber: "INV-" + Date.now()
  });
  res.json(invoice);
};

exports.getInvoices = async (req, res) => {
  const invoices = await Invoice.find().sort({ createdAt: -1 });
  res.json(invoices);
};

exports.downloadInvoice = async (req, res) => {
  const invoice = await Invoice.findById(req.params.id);
  generateInvoicePDF(res, invoice);
};
