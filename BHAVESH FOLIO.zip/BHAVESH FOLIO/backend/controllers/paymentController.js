const axios = require("axios");
const Invoice = require("../models/Invoice");

exports.createPayment = async (req, res) => {
  const invoice = await Invoice.findById(req.params.id);

  const orderId = "ORD_" + Date.now();

  const response = await axios.post(
    `${process.env.CASHFREE_BASE_URL}/orders`,
    {
      order_id: orderId,
      order_amount: invoice.amount,
      order_currency: "INR",
      customer_details: {
        customer_name: invoice.clientName,
        customer_email: invoice.clientEmail,
        customer_phone: "9999999999"
      }
    },
    {
      headers: {
        "x-client-id": process.env.CASHFREE_APP_ID,
        "x-client-secret": process.env.CASHFREE_SECRET,
        "Content-Type": "application/json"
      }
    }
  );

  invoice.paymentLink = response.data.payment_link;
  invoice.orderId = orderId;
  await invoice.save();

  res.json({ paymentLink: invoice.paymentLink });
};
