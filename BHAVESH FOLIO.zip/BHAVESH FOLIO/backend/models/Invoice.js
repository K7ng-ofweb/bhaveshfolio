const mongoose = require("mongoose");

const InvoiceSchema = new mongoose.Schema({
  invoiceNumber: String,
  clientName: String,
  clientEmail: String,
  service: String,
  amount: Number,
  status: {
    type: String,
    default: "Pending"
  },
  paymentLink: String,
  orderId: String
}, { timestamps: true });

module.exports = mongoose.model("Invoice", InvoiceSchema);
