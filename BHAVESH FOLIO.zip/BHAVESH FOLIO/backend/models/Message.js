const mongoose = require("mongoose");

const MessageSchema = new mongoose.Schema({
  name: String,
  email: String,
  message: String,
  status: { type: String, default: "New" }
}, { timestamps: true });

module.exports = mongoose.model("Message", MessageSchema);
