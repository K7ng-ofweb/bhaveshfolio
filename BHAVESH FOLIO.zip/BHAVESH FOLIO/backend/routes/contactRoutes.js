const router = require("express").Router();
const auth = require("../middleware/authMiddleware");
const {
  sendMessage,
  getMessages
} = require("../controllers/contactController");

router.post("/", sendMessage);
router.get("/", auth, getMessages);

module.exports = router;
