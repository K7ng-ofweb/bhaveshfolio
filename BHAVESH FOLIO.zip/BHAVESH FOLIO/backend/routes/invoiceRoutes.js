const router = require("express").Router();
const auth = require("../middleware/authMiddleware");
const {
  createInvoice,
  getInvoices,
  downloadInvoice
} = require("../controllers/invoiceController");

router.post("/", auth, createInvoice);
router.get("/", auth, getInvoices);
router.get("/:id/pdf", auth, downloadInvoice);

module.exports = router;
