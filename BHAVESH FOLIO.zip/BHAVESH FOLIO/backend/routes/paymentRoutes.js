const router = require("express").Router();
const Invoice = require("../models/Invoice");

router.post("/webhook", async (req, res) => {
  const { order_id, order_status } = req.body.data;

  if (order_status === "PAID") {
    await Invoice.findOneAndUpdate(
      { orderId: order_id },
      { status: "Paid" }
    );
  }

  res.json({ status: "ok" });
});

module.exports = router;
