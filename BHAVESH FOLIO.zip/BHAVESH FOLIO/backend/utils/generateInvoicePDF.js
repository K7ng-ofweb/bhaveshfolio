const PDFDocument = require("pdfkit");

module.exports = function generateInvoice(res, invoice) {
  const doc = new PDFDocument({ margin: 50 });

  res.setHeader("Content-Type", "application/pdf");
  res.setHeader(
    "Content-Disposition",
    `attachment; filename=invoice-${invoice.invoiceNumber}.pdf`
  );

  doc.pipe(res);

  doc.fontSize(20).text("INVOICE", { align: "right" });
  doc.moveDown();

  doc.fontSize(12).text(`Invoice No: ${invoice.invoiceNumber}`);
  doc.text(`Date: ${new Date(invoice.createdAt).toDateString()}`);
  doc.moveDown();

  doc.text(`Billed To:`);
  doc.text(invoice.clientName);
  doc.text(invoice.clientEmail);
  doc.moveDown();

  doc.text(`Service: ${invoice.service}`);
  doc.text(`Amount: ₹${invoice.amount}`);
  doc.moveDown();

  doc.fontSize(14).text(`Total: ₹${invoice.amount}`, { align: "right" });

  doc.moveDown(2);
  doc.fontSize(10).text(
    "Thank you for your business.",
    { align: "center", opacity: 0.6 }
  );

  doc.end();
};
