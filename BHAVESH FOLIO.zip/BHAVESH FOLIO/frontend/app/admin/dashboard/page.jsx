import AdminLayout from "@/components/admin/AdminLayout";
import StatCard from "@/components/admin/StatCard";

export default function Dashboard() {
  return (
    <AdminLayout>
      <h1 className="text-2xl font-serif mb-8">Dashboard</h1>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Projects" value="4" />
        <StatCard title="Messages" value="12" />
        <StatCard title="Invoices" value="0" />
        <StatCard title="Revenue" value="₹0" />
      </div>
    </AdminLayout>
  );
}
