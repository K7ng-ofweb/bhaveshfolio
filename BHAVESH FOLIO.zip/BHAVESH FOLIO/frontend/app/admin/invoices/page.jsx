<button
  onClick={async () => {
    const res = await fetch(
      `http://localhost:5000/api/payments/create/${inv._id}`,
      {
        method: "POST",
        headers: {
          Authorization: localStorage.getItem("token")
        }
      }
    );
    const data = await res.json();
    window.open(data.paymentLink, "_blank");
  }}
  className="text-green-600"
>
  Pay
</button>
