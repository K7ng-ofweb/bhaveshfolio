"use client";
import { useEffect, useState } from "react";
import AdminLayout from "@/components/admin/AdminLayout";

export default function Messages() {
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/api/contact", {
      headers: {
        Authorization: localStorage.getItem("token")
      }
    })
      .then(res => res.json())
      .then(setMessages);
  }, []);

  return (
    <AdminLayout>
      <h1 className="text-2xl font-serif mb-6">Messages</h1>

      <div className="space-y-4">
        {messages.map(m => (
          <div key={m._id} className="p-4 border rounded">
            <h3 className="font-medium">{m.name}</h3>
            <p className="text-sm opacity-70">{m.email}</p>
            <p className="mt-2">{m.message}</p>
          </div>
        ))}
      </div>
    </AdminLayout>
  );
}
