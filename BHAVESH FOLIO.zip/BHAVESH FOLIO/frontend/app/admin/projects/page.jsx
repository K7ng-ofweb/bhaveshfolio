"use client";
import { useEffect, useState } from "react";
import AdminLayout from "@/components/admin/AdminLayout";

export default function ProjectsAdmin() {
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/api/projects")
      .then(res => res.json())
      .then(setProjects);
  }, []);

  const deleteProject = async (id) => {
    await fetch(`http://localhost:5000/api/projects/${id}`, {
      method: "DELETE",
      headers: {
        Authorization: localStorage.getItem("token")
      }
    });
    setProjects(projects.filter(p => p._id !== id));
  };

  return (
    <AdminLayout>
      <h1 className="text-2xl font-serif mb-6">Projects</h1>

      <div className="space-y-4">
        {projects.map(p => (
          <div key={p._id} className="p-4 border rounded flex justify-between">
            <div>
              <h3 className="font-medium">{p.title}</h3>
              <p className="text-sm opacity-70">{p.category}</p>
            </div>
            <button
              onClick={() => deleteProject(p._id)}
              className="text-red-500"
            >
              Delete
            </button>
          </div>
        ))}
      </div>
    </AdminLayout>
  );
}
