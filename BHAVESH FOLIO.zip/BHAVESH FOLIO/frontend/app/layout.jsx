import "./globals.css";
import { ThemeProvider } from "next-themes";

export const metadata = {
  title: "Bhavesh Bafna R | Portfolio",
  description: "Luxury Personal Portfolio"
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <ThemeProvider attribute="class" defaultTheme="dark">
          {children}
        </ThemeProvider>
      </body>
    </html>
  );
}
