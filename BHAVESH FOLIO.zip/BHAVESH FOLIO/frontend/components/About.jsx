"use client";
import { motion } from "framer-motion";

export default function About() {
  return (
    <section id="about" className="px-6 md:px-20 py-24">
      <div className="max-w-4xl">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-2xl md:text-4xl font-serif"
        >
          About Me
        </motion.h2>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="mt-6 text-sm md:text-lg leading-relaxed opacity-80"
        >
          I’m <span className="text-luxury font-medium">Bhavesh Bafna R</span>,
          a web designer and frontend developer focused on building elegant,
          high-performance digital experiences. I combine clean design,
          modern technologies, and business understanding to create
          websites that not only look premium but also convert.
        </motion.p>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="mt-6 text-sm md:text-lg leading-relaxed opacity-80"
        >
          My work philosophy is simple — quality over quantity.
          Every project is crafted with attention to detail,
          mobile-first thinking, and long-term scalability.
        </motion.p>
      </div>
    </section>
  );
}
