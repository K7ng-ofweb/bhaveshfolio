"use client";
import { motion } from "framer-motion";
import { useState } from "react";

export default function Contact() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    message: ""
  });

  const [status, setStatus] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus("Sending...");

    // Backend API will be connected later
    setTimeout(() => {
      setStatus("Message sent successfully ✔");
      setForm({ name: "", email: "", message: "" });
    }, 1200);
  };

  return (
    <section id="contact" className="px-6 md:px-20 py-24">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="text-2xl md:text-4xl font-serif"
      >
        Contact Me
      </motion.h2>

      <p className="mt-3 max-w-xl text-sm md:text-base opacity-70">
        Have a project in mind or want to collaborate?  
        Fill the form and I’ll get back to you.
      </p>

      <motion.form
        onSubmit={handleSubmit}
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ delay: 0.3 }}
        className="mt-12 max-w-xl space-y-6 
        backdrop-blur-xl bg-white/70 dark:bg-darkcard/70 
        border border-black/10 dark:border-white/10 
        rounded-2xl p-6"
      >
        <input
          type="text"
          name="name"
          placeholder="Your Name"
          value={form.name}
          onChange={handleChange}
          required
          className="w-full px-4 py-3 rounded-lg 
          bg-transparent border border-black/20 
          dark:border-white/20 focus:outline-none"
        />

        <input
          type="email"
          name="email"
          placeholder="Your Email"
          value={form.email}
          onChange={handleChange}
          required
          className="w-full px-4 py-3 rounded-lg 
          bg-transparent border border-black/20 
          dark:border-white/20 focus:outline-none"
        />

        <textarea
          name="message"
          placeholder="Your Message"
          rows="4"
          value={form.message}
          onChange={handleChange}
          required
          className="w-full px-4 py-3 rounded-lg 
          bg-transparent border border-black/20 
          dark:border-white/20 focus:outline-none resize-none"
        />

        <button
          type="submit"
          className="w-full py-3 rounded-full 
          bg-luxury text-black font-medium transition"
        >
          Send Message
        </button>

        {status && (
          <p className="text-sm text-center opacity-80">
            {status}
          </p>
        )}
      </motion.form>
    </section>
  );
}
