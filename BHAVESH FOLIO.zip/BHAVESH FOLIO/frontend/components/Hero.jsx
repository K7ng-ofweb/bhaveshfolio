"use client";
import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="min-h-screen flex flex-col justify-center px-6 md:px-20">
      <motion.h1
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="text-4xl md:text-6xl font-serif tracking-wide"
      >
        BHAVESH BAFNA R
      </motion.h1>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="mt-4 text-sm md:text-lg opacity-70"
      >
        Web Designer • Frontend Developer • Affiliate Marketer
      </motion.p>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="mt-10 flex gap-4"
      >
        <button className="px-6 py-3 rounded-full bg-luxury text-black font-medium">
          View Projects
        </button>

        <button className="px-6 py-3 rounded-full border border-current">
          Hire Me
        </button>
      </motion.div>
    </section>
  );
}
