"use client";
import { motion } from "framer-motion";

export default function ProjectCard({ project }) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.3 }}
      className="rounded-2xl overflow-hidden border border-black/10 
      dark:border-white/10 bg-white dark:bg-darkcard"
    >
      <div className="aspect-[4/3] overflow-hidden">
        <img
          src={project.image}
          alt={project.title}
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
        />
      </div>

      <div className="p-4">
        <p className="text-xs uppercase tracking-widest opacity-60">
          {project.category}
        </p>

        <h3 className="mt-1 text-lg font-medium">
          {project.title}
        </h3>

        <p className="mt-2 text-sm opacity-70 line-clamp-2">
          {project.description}
        </p>

        {project.url && (
          <a
            href={project.url}
            target="_blank"
            className="inline-block mt-4 text-sm text-luxury"
          >
            View Project →
          </a>
        )}
      </div>
    </motion.div>
  );
}
