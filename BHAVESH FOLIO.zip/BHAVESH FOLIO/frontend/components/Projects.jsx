"use client";
import ProjectCard from "./ProjectCard";
import { motion } from "framer-motion";

/* TEMP DATA (will be replaced by backend API) */
const projects = [
  {
    title: "Luxury Portfolio Website",
    category: "Web Design",
    description: "High-end personal portfolio with admin CMS and payments.",
    image: "https://images.unsplash.com/photo-1521737604893-d14cc237f11d",
    url: "#"
  },
  {
    title: "E-Commerce Landing Page",
    category: "UI / UX",
    description: "Conversion-focused landing page with premium visuals.",
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085",
    url: "#"
  }
];

export default function Projects() {
  return (
    <section id="projects" className="px-6 md:px-20 py-20">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="text-2xl md:text-4xl font-serif"
      >
        Selected Projects
      </motion.h2>

      <p className="mt-3 max-w-xl text-sm md:text-base opacity-70">
        A curated selection of my recent work — focused on quality,
        performance, and premium experience.
      </p>

      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {projects.map((project, index) => (
          <ProjectCard key={index} project={project} />
        ))}
      </div>
    </section>
  );
}
