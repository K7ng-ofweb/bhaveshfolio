"use client";
import { motion } from "framer-motion";

const services = [
  {
    title: "Web Design",
    desc: "Luxury, conversion-focused websites with premium visual identity."
  },
  {
    title: "Frontend Development",
    desc: "High-performance, mobile-first interfaces using modern frameworks."
  },
  {
    title: "UI / UX Design",
    desc: "User-centric design systems crafted for clarity and elegance."
  },
  {
    title: "Affiliate Marketing",
    desc: "Optimized funnels and landing pages that generate passive income."
  }
];

export default function Services() {
  return (
    <section id="services" className="px-6 md:px-20 py-20 bg-black/5 dark:bg-white/5">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="text-2xl md:text-4xl font-serif"
      >
        Services
      </motion.h2>

      <p className="mt-3 max-w-xl text-sm md:text-base opacity-70">
        I offer end-to-end digital solutions focused on quality, performance,
        and long-term value.
      </p>

      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {services.map((service, i) => (
          <motion.div
            key={i}
            whileHover={{ y: -6 }}
            transition={{ duration: 0.3 }}
            className="rounded-2xl p-6 bg-white dark:bg-darkcard 
            border border-black/10 dark:border-white/10"
          >
            <div className="w-10 h-10 rounded-full bg-luxury/20 flex items-center justify-center text-luxury font-bold">
              {i + 1}
            </div>

            <h3 className="mt-6 text-lg font-medium">
              {service.title}
            </h3>

            <p className="mt-3 text-sm opacity-70">
              {service.desc}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
