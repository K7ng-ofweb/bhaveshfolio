"use client";
import { useTheme } from "next-themes";

export default function ThemeToggle() {
  const { theme, setTheme } = useTheme();

  return (
    <button
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
      className="fixed top-5 right-5 z-50 px-4 py-2 rounded-full 
      bg-black text-white dark:bg-white dark:text-black 
      border border-white/10 backdrop-blur-md transition"
    >
      {theme === "dark" ? "Light" : "Dark"}
    </button>
  );
}
