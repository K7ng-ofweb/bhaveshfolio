"use client";

export default function AdminLayout({ children }) {
  return (
    <div className="min-h-screen flex bg-gray-100 dark:bg-darkbg">
      <aside className="w-60 hidden md:block p-6 border-r border-black/10 dark:border-white/10">
        <h2 className="text-xl font-serif">Admin</h2>
        <nav className="mt-8 space-y-4 text-sm opacity-80">
          <a href="/admin/dashboard">Dashboard</a>
          <a href="/admin/projects">Projects</a>
          <a href="/admin/messages">Messages</a>
          <a href="/admin/invoices">Invoices</a>

        </nav>
      </aside>

      <main className="flex-1 p-6">{children}</main>
    </div>
  );
}
