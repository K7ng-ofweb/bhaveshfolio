export default function StatCard({ title, value }) {
  return (
    <div className="p-6 rounded-2xl bg-white dark:bg-darkcard border">
      <p className="text-sm opacity-70">{title}</p>
      <h3 className="text-2xl font-medium mt-2">{value}</h3>
    </div>
  );
}
