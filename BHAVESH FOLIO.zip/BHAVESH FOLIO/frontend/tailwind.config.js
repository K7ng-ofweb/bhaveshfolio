module.exports = {
  darkMode: "class",
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        luxury: "#C9A24D",
        darkbg: "#0B0B0C",
        darkcard: "#141416"
      }
    }
  },
  plugins: []
}
